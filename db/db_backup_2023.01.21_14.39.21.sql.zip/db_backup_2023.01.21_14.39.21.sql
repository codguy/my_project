SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
-- -------------------------------------------
SET AUTOCOMMIT=0;
START TRANSACTION;
SET SQL_QUOTE_SHOW_CREATE = 1;
-- -------------------------------------------

-- -------------------------------------------

-- START BACKUP

-- -------------------------------------------

-- -------------------------------------------

-- TABLE `migration`

-- -------------------------------------------
DROP TABLE IF EXISTS `migration`;
CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- -------------------------------------------

-- TABLE `tbl_about`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_about`;
CREATE TABLE IF NOT EXISTS `tbl_about` (
  `id` int NOT NULL AUTO_INCREMENT,
  `intro` text NOT NULL,
  `address` text NOT NULL,
  `education` text NOT NULL,
  `location` text NOT NULL,
  `work` text NOT NULL,
  `hobbies` text NOT NULL,
  `created_by_id` int NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx-about-created_by_id` (`created_by_id`),
  CONSTRAINT `fk-about-created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- -------------------------------------------

-- TABLE `tbl_action_log`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_action_log`;
CREATE TABLE IF NOT EXISTS `tbl_action_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` varchar(10) DEFAULT NULL,
  `controller` varchar(20) NOT NULL,
  `action` varchar(20) NOT NULL,
  `params` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `type` varchar(10) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx-action_log-created_by_id` (`created_by_id`),
  KEY `idx-action_log-controller` (`controller`),
  CONSTRAINT `fk-action_log-created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- -------------------------------------------

-- TABLE `tbl_chapter`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_chapter`;
CREATE TABLE IF NOT EXISTS `tbl_chapter` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `desciption` text,
  `dificulty` tinyint DEFAULT NULL,
  `course_id` int DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int DEFAULT '1',
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx-chapter-created_by_id` (`created_by_id`),
  KEY `idx-chapter-course_id` (`course_id`),
  CONSTRAINT `fk-chapter-course_id` FOREIGN KEY (`course_id`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk-chapter-created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- -------------------------------------------

-- TABLE `tbl_course`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_course`;
CREATE TABLE IF NOT EXISTS `tbl_course` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `desciption` text,
  `dificulty` tinyint DEFAULT NULL,
  `trainer_id` int DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int DEFAULT '1',
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx-course-created_by_id` (`created_by_id`),
  KEY `idx-trainer-trainer_id` (`trainer_id`),
  CONSTRAINT `fk-course-created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk-trainer-trainer_id` FOREIGN KEY (`trainer_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- -------------------------------------------

-- TABLE `tbl_dept`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_dept`;
CREATE TABLE IF NOT EXISTS `tbl_dept` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `field` varchar(25) DEFAULT NULL,
  `school_name` varchar(25) DEFAULT NULL,
  `hod_id` int DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int DEFAULT '1',
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx-dept-created_by_id` (`created_by_id`),
  CONSTRAINT `fk-dept-created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- -------------------------------------------

-- TABLE `tbl_discussion`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_discussion`;
CREATE TABLE IF NOT EXISTS `tbl_discussion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  `user_id` int DEFAULT '1',
  `replied_to` int DEFAULT '1',
  `model` varchar(255) NOT NULL,
  `model_id` int NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int DEFAULT '1',
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx-discussion-created_by_id` (`created_by_id`),
  KEY `idx-discussion-model` (`model`),
  KEY `idx-discussion-replied_to` (`replied_to`),
  CONSTRAINT `fk-discussion-created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk-discussion-replied_to` FOREIGN KEY (`replied_to`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- -------------------------------------------

-- TABLE `tbl_email_tempalte`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_email_tempalte`;
CREATE TABLE IF NOT EXISTS `tbl_email_tempalte` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `html` text NOT NULL,
  `json` text NOT NULL,
  `created_by_id` int NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx-tempalte-created_by_id` (`created_by_id`),
  CONSTRAINT `fk-tempalte-created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- -------------------------------------------

-- TABLE `tbl_feed`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_feed`;
CREATE TABLE IF NOT EXISTS `tbl_feed` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `desciption` text,
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int DEFAULT '1',
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx-feed-created_by_id` (`created_by_id`),
  KEY `idx-feed-title` (`title`),
  CONSTRAINT `fk-feed-created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- -------------------------------------------

-- TABLE `tbl_follow`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_follow`;
CREATE TABLE IF NOT EXISTS `tbl_follow` (
  `id` int NOT NULL AUTO_INCREMENT,
  `model` varchar(255) DEFAULT NULL,
  `model_id` int NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int DEFAULT '1',
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx-follow-created_by_id` (`created_by_id`),
  CONSTRAINT `fk-follow-created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- -------------------------------------------

-- TABLE `tbl_image`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_image`;
CREATE TABLE IF NOT EXISTS `tbl_image` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `folder` varchar(255) NOT NULL,
  `model` varchar(255) DEFAULT NULL,
  `model_id` int NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int DEFAULT '1',
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx-image-created_by_id` (`created_by_id`),
  CONSTRAINT `fk-image-created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- -------------------------------------------

-- TABLE `tbl_like`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_like`;
CREATE TABLE IF NOT EXISTS `tbl_like` (
  `id` int NOT NULL AUTO_INCREMENT,
  `model` varchar(255) DEFAULT NULL,
  `model_id` int NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int DEFAULT '1',
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx-like-created_by_id` (`created_by_id`),
  KEY `idx-like-model` (`model`),
  CONSTRAINT `fk-like-created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- -------------------------------------------

-- TABLE `tbl_log`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_log`;
CREATE TABLE IF NOT EXISTS `tbl_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ip` text NOT NULL,
  `action` text,
  `message` text NOT NULL,
  `created_by_id` int DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `type_id` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx-log-created_by_id` (`created_by_id`),
  KEY `idx-log-message` (`message`(768)),
  CONSTRAINT `fk-log-created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- -------------------------------------------

-- TABLE `tbl_message`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_message`;
CREATE TABLE IF NOT EXISTS `tbl_message` (
  `id` int NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  `user_id` int NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx-message-created_by_id` (`created_by_id`),
  KEY `idx-message-user_id` (`user_id`),
  CONSTRAINT `fk-message-created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk-message-user_id` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- -------------------------------------------

-- TABLE `tbl_notification`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_notification`;
CREATE TABLE IF NOT EXISTS `tbl_notification` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(25) NOT NULL,
  `type_id` tinyint NOT NULL,
  `state_id` tinyint NOT NULL,
  `to_user_id` int NOT NULL,
  `model` varchar(25) DEFAULT NULL,
  `model_id` int NOT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx-notification-created_by_id` (`created_by_id`),
  KEY `idx-notification-to_user_id` (`to_user_id`),
  CONSTRAINT `fk-notification-created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk-notification-to_user_id` FOREIGN KEY (`to_user_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- -------------------------------------------

-- TABLE `tbl_skill`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_skill`;
CREATE TABLE IF NOT EXISTS `tbl_skill` (
  `id` int NOT NULL AUTO_INCREMENT,
  `model` varchar(255) DEFAULT NULL,
  `model_id` int NOT NULL,
  `skill` varchar(25) NOT NULL,
  `level` tinyint NOT NULL DEFAULT '1',
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int DEFAULT '1',
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx-skill-model` (`model`),
  KEY `idx-skill-created_by_id` (`created_by_id`),
  CONSTRAINT `fk-skill-created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- -------------------------------------------

-- TABLE `tbl_social_link`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_social_link`;
CREATE TABLE IF NOT EXISTS `tbl_social_link` (
  `id` int NOT NULL AUTO_INCREMENT,
  `platform` varchar(255) NOT NULL,
  `link` text NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int DEFAULT '1',
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx-social_link-created_by_id` (`created_by_id`),
  CONSTRAINT `fk-social_link-created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- -------------------------------------------

-- TABLE `tbl_tag`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_tag`;
CREATE TABLE IF NOT EXISTS `tbl_tag` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tags` varchar(20) NOT NULL,
  `model` varchar(15) DEFAULT NULL,
  `model_id` int DEFAULT NULL,
  `created_by_id` int DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx-tag-created_by_id` (`created_by_id`),
  KEY `idx-tag-tags` (`tags`),
  CONSTRAINT `fk-tag-created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- -------------------------------------------

-- TABLE `tbl_user`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(30) NOT NULL,
  `roll_id` tinyint NOT NULL,
  `state_id` tinyint NOT NULL,
  `dob` date DEFAULT NULL,
  `authKey` varchar(10) NOT NULL,
  `accessToken` varchar(10) NOT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int DEFAULT '1',
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


COMMIT;
-- -------------------------------------------
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
 -- -------AutobackUpStart------ -- -------------------------------------------

-- -------------------------------------------

-- END BACKUP

-- -------------------------------------------
